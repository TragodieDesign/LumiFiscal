
const AuthScreen =() => {
    console.log ("Menu renderizado")
    return (
        <div>
            <h1> Dashboard</h1>
        </div>
    )
}









export default AuthScreen;



