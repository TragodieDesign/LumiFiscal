
const Birthday =() => {
    console.log ("Menu renderizado")
    return (
        <div>

          aa

            
        </div>
    )
}









export default Birthday;



