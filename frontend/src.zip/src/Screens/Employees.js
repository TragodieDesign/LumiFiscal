import * as React from 'react';
import UserList from '../components/users/UserList';


const Employees =() => {
    console.log ("Menu renderizado")
    return (
        <div>
          <UserList/>
        </div>
    )
}









export default Employees;



