
import './sidebar.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faUser,
  faGauge,
  faEnvelope,
  faGear,
  faCakeCandles
} from '@fortawesome/free-solid-svg-icons';
import { Link,   

      } from 'react-router-dom';



const MenuMain =() => {
    console.log ("Menu renderizado")
    return(
        <div className='main-sidebar'>

        <div className='buttons'>
        <Link to={'/'}>
      <button  > 
      <FontAwesomeIcon icon={faGauge} />
        Dashboard
        </button>
        </Link>

        <Link to={'/Employees'}>
      <button  > 
        <FontAwesomeIcon icon={faUser} />
        Colaboradores
        </button>
        </Link>
   
      <Link to ={'/MailSignature'}>
      <button>
      <FontAwesomeIcon icon={faEnvelope} />
        Assinaturas
        </button>
        </Link>
        <Link to ={'/Birthday'}>
      <button>
      <FontAwesomeIcon icon={faCakeCandles} />
        Aniversariantes
        </button>
        </Link>



        <Link to ={'/Options'}>
        <button > 
        <FontAwesomeIcon icon={faGear} />
        Opções
        </button>
        </Link>
        </div>




        
        </div>
        
    )
}









export default MenuMain;